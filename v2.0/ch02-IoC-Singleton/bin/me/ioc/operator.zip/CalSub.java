package me.ioc.operator;

public class CalSub implements Calculator {
	@Override
	public int operator(int x, int y) {
		// TODO Auto-generated method stub
		return x - y;
	}
}
