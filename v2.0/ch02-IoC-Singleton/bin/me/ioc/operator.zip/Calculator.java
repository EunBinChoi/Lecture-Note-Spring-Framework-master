package me.ioc.operator;

public interface Calculator {
	public int operator(int x, int y);
}
